/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe.part3;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
/**
 *
 * @author RC_Student_Lab
 */
public class PoePART3 {

    private static boolean exit;
    private static int totalMessages = 0;
    private static int messageCounter = 0;
    
    // Colors for modern UI
    private static final Color PRIMARY_COLOR = new Color(41, 128, 185);
    private static final Color SECONDARY_COLOR = new Color(52, 152, 219);
    private static final Color ACCENT_COLOR = new Color(231, 76, 60);
    private static final Color BACKGROUND_COLOR = new Color(236, 240, 241);
    private static final Color CARD_COLOR = Color.WHITE;
    private static final Color TEXT_COLOR = new Color(52, 73, 94);
    
    // Arrays for storing different types of messages
    private static final int MAX_MESSAGES = 100;
    
    // Sent Messages arrays
    private static String[] sentMessages = new String[MAX_MESSAGES];
    private static String[] sentRecipients = new String[MAX_MESSAGES];
    private static String[] sentMessageContents = new String[MAX_MESSAGES];
    private static int sentCount = 0;
    
    // Disregarded Messages arrays
    private static String[] disregardedMessages = new String[MAX_MESSAGES];
    private static String[] disregardedRecipients = new String[MAX_MESSAGES];
    private static String[] disregardedMessageContents = new String[MAX_MESSAGES];
    private static int disregardedCount = 0;
    
    // Stored Messages arrays
    private static String[] storedMessages = new String[MAX_MESSAGES];
    private static String[] storedRecipients = new String[MAX_MESSAGES];
    private static String[] storedMessageContents = new String[MAX_MESSAGES];
    private static int storedCount = 0;
    
    // Message Hash and ID arrays
    private static String[] messageHashes = new String[MAX_MESSAGES];
    private static String[] messageIDs = new String[MAX_MESSAGES];
    
    static final JSONArray messageStorage = new JSONArray();

public static void main(String[] args) {
    // Set modern look and feel
    setModernLookAndFeel();  // Correct method name
    
    initializeTestData();
    
    if (!showLoginScreen()) {
        return;
    }

    showMainMenu();
    
    JOptionPane.showMessageDialog(null, 
        createStyledMessage("Total messages sent: " + totalMessages),
        "Let's Fly Summary", 
        JOptionPane.INFORMATION_MESSAGE);
    saveMessagesToJSON();
}


private static void setModernLookAndFeel() {
    try {
        UIManager.setLookAndFeel(UIManager.getLookAndFeel());

        // Customize UI defaults for better appearance
        UIManager.put("OptionPane.background", BACKGROUND_COLOR);
        UIManager.put("Panel.background", BACKGROUND_COLOR);
        UIManager.put("OptionPane.messageForeground", TEXT_COLOR);
        UIManager.put("Button.background", PRIMARY_COLOR);
        UIManager.put("Button.foreground", Color.WHITE);
        UIManager.put("Button.focus", new Color(0, 0, 0, 0));
    } catch (Exception e) {
        e.printStackTrace();
    }
}
    
    private static JPanel createStyledPanel(String title) {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.setBackground(BACKGROUND_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        if (title != null) {
            JLabel titleLabel = new JLabel(title);
            titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
            titleLabel.setForeground(PRIMARY_COLOR);
            titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
            panel.add(titleLabel, BorderLayout.NORTH);
        }
        
        return panel;
    }
    
    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(PRIMARY_COLOR);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(PRIMARY_COLOR.darker(), 1),
            BorderFactory.createEmptyBorder(12, 25, 12, 25)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(SECONDARY_COLOR);
            }
            
            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(PRIMARY_COLOR);
            }
        });
        
        return button;
    }
    
    private static String createStyledMessage(String message) {
        return "<html><div style='text-align: center; padding: 10px;'>" + message + "</div></html>";
    }
    
    private static JTextArea createStyledTextArea(String content) {
        JTextArea textArea = new JTextArea(content);
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setBackground(CARD_COLOR);
        textArea.setForeground(TEXT_COLOR);
        textArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textArea.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        return textArea;
    }
    
    private static boolean showLoginScreen() {
        JPanel loginPanel = createStyledPanel("🔐 Let's Fly Login");
        loginPanel.setLayout(new GridLayout(3, 2, 10, 10));
        
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        userLabel.setForeground(TEXT_COLOR);
        
        JTextField userField = new JTextField();
        userField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        userField.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        passLabel.setForeground(TEXT_COLOR);
        
        JPasswordField passField = new JPasswordField();
        passField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        passField.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        
        loginPanel.add(userLabel);
        loginPanel.add(userField);
        loginPanel.add(passLabel);
        loginPanel.add(passField);
        
        // Add some spacing
        loginPanel.add(new JLabel());
        loginPanel.add(new JLabel());
        
        int result = JOptionPane.showConfirmDialog(null, loginPanel, 
            "Let's Fly - Secure Login", JOptionPane.OK_CANCEL_OPTION, 
            JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            String userName = userField.getText();
            String passWord = new String(passField.getPassword());
            
            if ("administrator".equals(userName) && "5678".equals(passWord)) {
                showSuccessMessage("Login successful! Welcome to Let's Fly! 🎉");
                return true;
            } else {
                showErrorMessage("Login failed. Please check your credentials.");
                return false;
            }
        }
        return false;
    }
    
    private static void showMainMenu() {
        while (!exit) {
            JPanel menuPanel = createStyledPanel(" Let's Fly Dashboard");
            menuPanel.setLayout(new GridLayout(0, 1, 10, 10));
            
            // Add statistics
            JLabel statsLabel = new JLabel(
                "<html><div style='text-align: center; background: #e8f4fd; padding: 10px; border-radius: 5px;'>" +
                "📊 Statistics: " + totalMessages + " sent messages • " + storedCount + " stored • " + disregardedCount + " disregarded" +
                "</div></html>"
            );
            statsLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
            menuPanel.add(statsLabel);
            
            // Menu buttons
            String[] menuItems = {
                " Convey a Message",
                " View Previous Messages", 
                " Display Sender and Recipient",
                " Display Longest Message",
                " Search Message by ID",
                " Search Messages by Recipient",
                "️ Delete Message by Hash",
                " Display Full Message Report",
                " Exit Let's Fly"
            };
            
            for (String item : menuItems) {
                JButton button = createStyledButton(item);
                button.addActionListener(e -> handleMenuSelection(item));
                menuPanel.add(button);
            }
            
            int result = JOptionPane.showOptionDialog(null, menuPanel, 
                "Let's Fly Menu v2.0", JOptionPane.DEFAULT_OPTION, 
                JOptionPane.PLAIN_MESSAGE, null, new Object[]{}, null);
            
            if (result == JOptionPane.CLOSED_OPTION) {
                exit = true;
            }
        }
    }
    
    private static void handleMenuSelection(String menuItem) {
        switch (menuItem) {
            case " Convey a Message":
                sendMessage();
                break;
            case " View Previous Messages":
                showRecentlySentMessages();
                break;
            case " Display Sender and Recipient":
                displaySenderAndRecipient();
                break;
            case " Display Longest Message":
                displayLongestMessage();
                break;
            case " Search Message by ID":
                searchMessageID();
                break;
            case " Search Messages by Recipient":
                searchByRecipient();
                break;
            case "️ Delete Message by Hash":
                deleteByHash();
                break;
            case " Display Full Message Report":
                displayFullReport();
                break;
            case " Exit Let's Fly":
                exit = true;
                showSuccessMessage("Thank you for using Let's Fly! Goodbye! 👋");
                break;
        }
    }
    
    private static void showSuccessMessage(String message) {
        JOptionPane.showMessageDialog(null, 
            createStyledMessage("✅ " + message),
            "Success", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void showErrorMessage(String message) {
        JOptionPane.showMessageDialog(null, 
            createStyledMessage("❌ " + message),
            "Error", 
            JOptionPane.ERROR_MESSAGE);
    }
    
    private static void showInfoMessage(String message) {
        JOptionPane.showMessageDialog(null, 
            createStyledMessage("ℹ️ " + message),
            "Information", 
            JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void initializeTestData() {
        // Test Data Message 1 - Sent
        addToSentMessages("+27834557896", "Did you get the cake?", "10000000001");
        
        // Test Data Message 2 - Stored
        addToStoredMessages("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        
        // Test Data Message 3 - Disregarded
        addToDisregardedMessages("+27834484567", "Yohoooo, I am at your gate.");
        
        // Test Data Message 4 - Sent
        addToSentMessages("0838884567", "It is dinner time!", "10000000004");
        
        // Test Data Message 5 - Stored
        addToStoredMessages("+27838884567", "Ok, I am leaving without you.");
    }
    
    private static void addToSentMessages(String recipient, String message, String messageId) {
        if (sentCount < MAX_MESSAGES) {
            sentRecipients[sentCount] = recipient;
            sentMessageContents[sentCount] = message;
            messageIDs[sentCount] = messageId;
            
            String hash = generateHash(messageId, message);
            messageHashes[sentCount] = hash;
            
            sentMessages[sentCount] = String.format(
                " ID: %s,  Hash: %s,  To: %s,  Message: %s",
                messageId, hash, recipient, message
            );
            sentCount++;
            totalMessages++;
        }
    }
    
    private static void addToStoredMessages(String recipient, String message) {
        if (storedCount < MAX_MESSAGES) {
            storedRecipients[storedCount] = recipient;
            storedMessageContents[storedCount] = message;
            storedMessages[storedCount] = String.format(" To: %s |  Message: %s", recipient, message);
            storedCount++;
        }
    }
    
    private static void addToDisregardedMessages(String recipient, String message) {
        if (disregardedCount < MAX_MESSAGES) {
            disregardedRecipients[disregardedCount] = recipient;
            disregardedMessageContents[disregardedCount] = message;
            disregardedMessages[disregardedCount] = String.format(" To: %s |  Message: %s", recipient, message);
            disregardedCount++;
        }
    }
    
    private static String generateHash(String messageId, String message) {
        messageCounter++;
        String[] words = message.trim().split("\\s+");
        return String.format("%02d:%d:%s:%s",
                Long.parseLong(messageId.substring(0, 2)),
                messageCounter,
                words[0].toUpperCase(),
                words.length > 1 ? words[words.length - 1].toUpperCase() : "");
    }

    static void sendMessage() {
        JPanel messagePanel = createStyledPanel(" Compose New Message");
        messagePanel.setLayout(new GridLayout(3, 2, 10, 10));
        
        JLabel recipientLabel = new JLabel("Recipient Number:");
        recipientLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        JTextField recipientField = new JTextField();
        recipientField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        recipientField.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        
        JLabel messageLabel = new JLabel("Message (max 250 chars):");
        messageLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        
        JTextArea messageArea = new JTextArea(4, 20);
        messageArea.setLineWrap(true);
        messageArea.setWrapStyleWord(true);
        messageArea.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        messageArea.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(189, 195, 199), 1),
            BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        
        JScrollPane scrollPane = new JScrollPane(messageArea);
        
        messagePanel.add(recipientLabel);
        messagePanel.add(recipientField);
        messagePanel.add(messageLabel);
        messagePanel.add(scrollPane);
        messagePanel.add(new JLabel()); // Empty cell for spacing
        messagePanel.add(new JLabel());
        
        int result = JOptionPane.showConfirmDialog(null, messagePanel, 
            "Compose Message", JOptionPane.OK_CANCEL_OPTION, 
            JOptionPane.PLAIN_MESSAGE);
        
        if (result == JOptionPane.OK_OPTION) {
            String recipient = recipientField.getText();
            String message = messageArea.getText();
            
            recipient = checkRecipient(recipient);
            if (recipient == null) return;

            if (message == null || message.length() > 250 || message.trim().isEmpty()) {
                showErrorMessage("Please enter a valid message of less than 250 characters.");
                return;
            }

            String[] actions = {" Send", " Disregard", " Store"};
            int action = JOptionPane.showOptionDialog(null,
                    createStyledMessage("Choose what to do with this message:\n\n" +
                            " To: " + recipient + "\n" +
                            " Message: " + (message.length() > 50 ? message.substring(0, 50) + "..." : message)),
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, actions, actions[0]);

            long messageId = 10000000000L + new Random().nextInt(900000000);
            JSONObject jsonMessage = new JSONObject();
            jsonMessage.put("MessageID", String.valueOf(messageId));
            jsonMessage.put("Recipient", recipient);
            jsonMessage.put("Message", message);

            switch (action) {
                case 0: // Send
                    String hash = generateHash(String.valueOf(messageId), message);
                    jsonMessage.put("MessageHash", hash);
                    addToSentMessages(recipient, message, String.valueOf(messageId));
                    messageStorage.add(jsonMessage);
                    totalMessages++;
                    showSuccessMessage(
                        "Message Sent Successfully!\n\n" +
                        " Message ID: " + messageId + "\n" +
                        " Message Hash: " + hash + "\n" +
                        " Recipient: " + recipient + "\n" +
                        " Message: " + message
                    );
                    break;

                case 1: // Disregard
                    addToDisregardedMessages(recipient, message);
                    showInfoMessage("Message has been disregarded.");
                    break;

                case 2: // Store
                    addToStoredMessages(recipient, message);
                    messageStorage.add(jsonMessage);
                    showSuccessMessage("Message has been stored successfully.");
                    break;

                default:
                    showInfoMessage("Message operation cancelled.");
                    break;
            }
        }
    }

    static void saveMessagesToJSON() {
        try (FileWriter file = new FileWriter("storedMessages.json")) {
            file.write(messageStorage.toJSONString());
            file.flush();
            System.out.println("Stored messages saved to storedMessages.json");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String checkRecipient(String recipient) {
        if (recipient == null || !recipient.matches("\\+?\\d{9,12}")) {
            showErrorMessage("Invalid number format. Must be 9-12 digits with optional '+' prefix.\n\nExample: +27834557896 or 0838884567");
            return null;
        }
        return recipient;
    }

    static void showRecentlySentMessages() {
        if (sentCount == 0) {
            showInfoMessage("No sent messages yet. Start by composing a new message! ");
            return;
        }

        StringBuilder output = new StringBuilder();
        output.append(" Recently Sent Messages\n");
        output.append("=====================\n\n");
        
        int start = Math.max(0, sentCount - 5); // Show last 5 messages
        
        for (int i = start; i < sentCount; i++) {
            output.append(" Message ").append(i - start + 1).append(":\n");
            output.append(sentMessages[i]).append("\n");
            output.append("─".repeat(50)).append("\n\n");
        }
        
        JTextArea textArea = createStyledTextArea(output.toString());
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(600, 400));
        
        JOptionPane.showMessageDialog(null, scrollPane, 
            "Recent Messages ", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void displaySenderAndRecipient() {
        if (sentCount == 0) {
            showInfoMessage("No sent messages yet. Start by composing a new message! ");
            return;
        }
        
        StringBuilder output = new StringBuilder();
        output.append(" Sender and Recipient Details\n");
        output.append("=============================\n\n");
        
        for (int i = 0; i < sentCount; i++) {
            output.append(" Message ").append(i + 1).append(":\n");
            output.append("    Sender: administrator\n");
            output.append("    Recipient: ").append(sentRecipients[i]).append("\n");
            output.append("─".repeat(35)).append("\n");
        }
        
        JTextArea textArea = createStyledTextArea(output.toString());
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        
        JOptionPane.showMessageDialog(null, scrollPane, 
            "Sender & Recipient Info ", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void displayLongestMessage() {
        if (sentCount == 0) {
            showInfoMessage("No sent messages yet. Start by composing a new message! ");
            return;
        }
        
        String longestMessage = "";
        int maxLength = 0;
        String recipient = "";
        String messageId = "";
        
        for (int i = 0; i < sentCount; i++) {
            if (sentMessageContents[i].length() > maxLength) {
                maxLength = sentMessageContents[i].length();
                longestMessage = sentMessageContents[i];
                recipient = sentRecipients[i];
                messageId = messageIDs[i];
            }
        }
        
        String output = " Longest Sent Message Analysis\n" +
                       "==============================\n\n" +
                       " Length: " + maxLength + " characters\n" +
                       " Message ID: " + messageId + "\n" +
                       " Recipient: " + recipient + "\n\n" +
                       " Message Content:\n" +
                       "─".repeat(40) + "\n" +
                       longestMessage;
        
        JTextArea textArea = createStyledTextArea(output);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        
        JOptionPane.showMessageDialog(null, scrollPane, 
            "Longest Message ", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private static void searchMessageID() {
        String searchId = JOptionPane.showInputDialog(null,
            createStyledMessage("Enter Message ID to search:\n\nExample: 10000000001"),
            "Search Message by ID ", JOptionPane.QUESTION_MESSAGE);
        
        if (searchId == null || searchId.trim().isEmpty()) {
            return;
        }
        
        for (int i = 0; i < sentCount; i++) {
            if (searchId.equals(messageIDs[i])) {
                String output = "✅ Message Found!\n\n" +
                               " Message ID: " + messageIDs[i] + "\n" +
                               " Hash: " + messageHashes[i] + "\n" +
                               " Recipient: " + sentRecipients[i] + "\n\n" +
                               " Message:\n" +
                               "─".repeat(40) + "\n" +
                               sentMessageContents[i];
                
                JTextArea textArea = createStyledTextArea(output);
                JScrollPane scrollPane = new JScrollPane(textArea);
                scrollPane.setPreferredSize(new Dimension(500, 250));
                
                JOptionPane.showMessageDialog(null, scrollPane, 
                    "Search Results 🔍", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        
        showErrorMessage("Message ID '" + searchId + "' not found in sent messages.");
    }
    
    private static void searchByRecipient() {
        String recipient = JOptionPane.showInputDialog(null,
            createStyledMessage("Enter recipient number to search:\n\nExample: +27838884567"),
            "Search by Recipient 📞", JOptionPane.QUESTION_MESSAGE);
        
        if (recipient == null || recipient.trim().isEmpty()) {
            return;
        }
        
        StringBuilder output = new StringBuilder();
        output.append("🔍 Search Results for: ").append(recipient).append("\n");
        output.append("================================\n\n");
        
        boolean found = false;
        
        // Search in sent messages
        output.append(" SENT MESSAGES:\n");
        output.append("─".repeat(20)).append("\n");
        for (int i = 0; i < sentCount; i++) {
            if (recipient.equals(sentRecipients[i])) {
                found = true;
                output.append("✅ ").append(sentMessageContents[i]).append("\n\n");
            }
        }
        
        // Search in stored messages
        output.append(" STORED MESSAGES:\n");
        output.append("─".repeat(20)).append("\n");
        for (int i = 0; i < storedCount; i++) {
            if (recipient.equals(storedRecipients[i])) {
                found = true;
                output.append("💾 ").append(storedMessageContents[i]).append("\n\n");
            }
        }
        
        if (found) {
            JTextArea textArea = createStyledTextArea(output.toString());
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(500, 300));
            
            JOptionPane.showMessageDialog(null, scrollPane, 
                "Recipient Search Results 📞", JOptionPane.INFORMATION_MESSAGE);
        } else {
            showErrorMessage("No messages found for recipient: " + recipient);
        }
    }
    
    private static void deleteByHash() {
        String hash = JOptionPane.showInputDialog(null,
            createStyledMessage("Enter Message Hash to delete:\n\nFormat: XX:counter:FIRST_WORD:LAST_WORD"),
            "Delete Message by Hash 🗑️", JOptionPane.WARNING_MESSAGE);
        
        if (hash == null || hash.trim().isEmpty()) {
            return;
        }
        
        for (int i = 0; i < sentCount; i++) {
            if (hash.equals(messageHashes[i])) {
                String deletedMessage = sentMessageContents[i];
                String deletedRecipient = sentRecipients[i];
                
                // Remove from arrays by shifting elements
                for (int j = i; j < sentCount - 1; j++) {
                    sentMessages[j] = sentMessages[j + 1];
                    sentRecipients[j] = sentRecipients[j + 1];
                    sentMessageContents[j] = sentMessageContents[j + 1];
                    messageIDs[j] = messageIDs[j + 1];
                    messageHashes[j] = messageHashes[j + 1];
                }
                sentCount--;
                totalMessages--;
                
                showSuccessMessage(
                    "Message successfully deleted! 🗑️\n\n" +
                    " Recipient: " + deletedRecipient + "\n" +
                    " Message: " + deletedMessage + "\n" +
                    " Hash: " + hash
                );
                return;
            }
        }
        
        showErrorMessage("Message with specified hash not found.\n\nHash: " + hash);
    }
    
    private static void displayFullReport() {
        if (sentCount == 0) {
            showInfoMessage("No sent messages yet. Start by composing a new message! 📝");
            return;
        }
        
        StringBuilder output = new StringBuilder();
        output.append(" FULL MESSAGE REPORT\n");
        output.append("=====================\n\n");
        output.append(" Total Sent Messages: ").append(totalMessages).append("\n\n");
        
        for (int i = 0; i < sentCount; i++) {
            output.append(" Message ").append(i + 1).append(":\n");
            output.append("    Message Hash: ").append(messageHashes[i]).append("\n");
            output.append("    Recipient: ").append(sentRecipients[i]).append("\n");
            output.append("    Message ID: ").append(messageIDs[i]).append("\n");
            output.append("    Content: ").append(sentMessageContents[i]).append("\n");
            output.append("─".repeat(60)).append("\n\n");
        }
        
        JTextArea textArea = createStyledTextArea(output.toString());
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(700, 500));
        
        JOptionPane.showMessageDialog(null, scrollPane, 
            "Full Message Report 📊", JOptionPane.INFORMATION_MESSAGE);
    }
    
    // Unit Test Helper Methods
    public static String[] getSentMessageContents() {
        return Arrays.copyOf(sentMessageContents, sentCount);
    }
    
    public static String getLongestMessage() {
        if (sentCount == 0) return "";
        
        String longest = sentMessageContents[0];
        for (int i = 1; i < sentCount; i++) {
            if (sentMessageContents[i].length() > longest.length()) {
                longest = sentMessageContents[i];
            }
        }
        return longest;
    }
    
    public static String searchMessagesByRecipient(String recipient) {
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < storedCount; i++) {
            if (recipient.equals(storedRecipients[i])) {
                if (result.length() > 0) result.append(", ");
                result.append(storedMessageContents[i]);
            }
        }
        return result.toString();
    }

}
